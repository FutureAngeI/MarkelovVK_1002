from django.shortcuts import render, get_object_or_404
from django.http import Http404
from .models import Post, Comment
from .forms import CommentForm
from django.views.decorators.http import require_POST


def post_list(request):
    posts = Post.objects.all()
    return render(
        request,
        'blog/post/list.html',
        {'posts': posts}
    )


def post_detail(request, id):
    try:
        post = Post.objects.get(id=id)
    except Post.objects.DoesNotExist:
        raise Http404("Пост не найден.")

    # список активных комментариев к этому посту
    comments = post.comments.filter(active=True)
    # форма для комментирования пользователями
    form = CommentForm()
    return render(request,
                  'blog/post/detail.html',
                  {
                      'post': post,
                      'comments': comments,
                      'form': form
                  })

@require_POST
def post_comment(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    comment = None
    # комментарий был отправлен
    form = CommentForm(data=request.POST)
    if form.is_valid():
        # создать объект класса Comment, не сохраняя его в базе данных
        comment = form.save(commit=False)
        # назначить пост комментарию
        comment.post = post
        # сохранить комментарий в базе данных
        comment.save()
    return render(request,
                  'blog/post/comment.html',
                  {
                      'post': post,
                      'form': form,
                      'comment': comment
                  })
