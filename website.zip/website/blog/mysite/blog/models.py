from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


# Модель для поста:
# заголовок, автор, содержание, дата публикации/создания/обновления поста.
# Поле author определяет взаимосвязь многие к-одному, означающую, что каждый
# пост написан пользователем и пользователь может написать любое число постов.
class Post(models.Model):
    title = models.CharField(max_length=250)
    author = models.ForeignKey(User,
                               on_delete=models.CASCADE,
                               related_name='blog_posts')
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    objects = models.Manager()

    class Meta:
        # определение предустановленного порядка сортировки
        ordering = ['-publish']
        # индекс повысит производительность запросов по полю publish
        indexes = [
            models.Index(fields=['-publish']),
        ]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('blog:post_detail',
                       args=[self.id])


# Модель комментария для поста с заданными полями
class Comment(models.Model):
    post = models.ForeignKey(Post,
                             on_delete=models.CASCADE,
                             related_name='comments')
    name = models.CharField(max_length=80)
    email = models.EmailField()
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['created']
        indexes = [
            models.Index(fields=['created']),
        ]

    def __str__(self):
        return f'Комментарий от {self.name} на {self.post}'
